import { useState } from 'react'

const NAV = [
  ['LayoutDashboard', 'Dashboard'], ['Users', 'Patients'], ['Stethoscope', 'Doctors'],
  ['CalendarEvent', 'Appointments'], ['Scissors', 'Surgeries'], ['IdBadge2', 'Employees'],
  ['Clock', 'Staff schedule'], ['Pill', 'Treatments'], ['Box', 'Inventory'], ['Receipt2', 'Billing'],
]

const STATS = [
  { label: 'Patients admitted', value: '128', sub: '+6 today', tint: 'var(--primary-soft)', color: 'var(--primary)' },
  { label: 'Doctors on duty', value: '34', sub: 'of 41 total', tint: 'var(--accent-soft)', color: 'var(--accent)' },
  { label: 'Surgeries scheduled', value: '7', sub: 'this week', tint: 'var(--warn-soft)', color: 'var(--warn)' },
  { label: 'Revenue this month', value: 'PKR 4.2M', sub: '+11% vs last month', tint: 'var(--success-soft)', color: 'var(--success)' },
]

const APPTS = [
  ['09:00', 'Ayesha Khan', 'Dr. Farooq (Cardiology)', 'Confirmed', 'success'],
  ['10:30', 'Bilal Ahmed', 'Dr. Zara (Orthopedics)', 'Confirmed', 'success'],
  ['11:15', 'Hina Malik', 'Dr. Farooq (Cardiology)', 'Pending', 'warn'],
  ['13:00', 'Usman Tariq', 'Dr. Noor (Pediatrics)', 'Cancelled', 'danger'],
]

const BEDS = [
  { ward: 'General ward', occ: 82, color: 'var(--primary)' },
  { ward: 'ICU', occ: 95, color: 'var(--danger)' },
  { ward: 'Maternity', occ: 60, color: 'var(--accent)' },
  { ward: 'Pediatrics', occ: 45, color: 'var(--success)' },
]

export default function App() {
  const [dark, setDark] = useState(false)
  const [active, setActive] = useState('Dashboard')

  return (
    <div className={dark ? 'dark' : ''} style={{ display: 'flex', minHeight: '100vh' }}>
      {/* Sidebar */}
      <aside style={{ width: 200, background: 'var(--sidebar)', color: '#cbd5e1', flexShrink: 0 }}>
        <div style={{ padding: '1rem', fontWeight: 500, color: '#fff', borderBottom: '0.5px solid #334155' }}>
          Riverside HMS
        </div>
        {NAV.map(([icon, label]) => (
          <div
            key={label}
            onClick={() => setActive(label)}
            style={{
              display: 'flex', alignItems: 'center', gap: 10, padding: '9px 1rem',
              fontSize: 13, cursor: 'pointer',
              background: active === label ? 'var(--sidebar-active)' : 'transparent',
              color: active === label ? '#fff' : '#cbd5e1',
            }}
          >
            {label}
          </div>
        ))}
      </aside>

      {/* Main */}
      <main style={{ flex: 1, background: 'var(--bg)', color: 'var(--ink)', padding: '1.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 500 }}>{active}</div>
            <div style={{ color: 'var(--sub)', fontSize: 13 }}>
              {new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </div>
          </div>
          <button
            onClick={() => setDark(d => !d)}
            style={{
              border: '0.5px solid var(--border)', background: 'var(--surface)', color: 'var(--ink)',
              borderRadius: 8, padding: '6px 12px', fontSize: 13, cursor: 'pointer',
            }}
          >
            {dark ? 'Light mode' : 'Dark mode'}
          </button>
        </div>

        {active !== 'Dashboard' ? (
          <div style={{ background: 'var(--surface)', border: '0.5px solid var(--border)', borderRadius: 10, padding: '2rem', color: 'var(--sub)' }}>
            {active} module — build this screen next.
          </div>
        ) : (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: '1.25rem' }}>
              {STATS.map(s => (
                <div key={s.label} style={{ background: s.tint, borderRadius: 10, padding: '0.85rem 1rem' }}>
                  <div style={{ fontSize: 12, color: s.color, fontWeight: 500, marginBottom: 4 }}>{s.label}</div>
                  <div style={{ fontSize: 20, fontWeight: 500 }}>{s.value}</div>
                  <div style={{ fontSize: 11, color: 'var(--sub)', marginTop: 2 }}>{s.sub}</div>
                </div>
              ))}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 12 }}>
              <div style={{ background: 'var(--surface)', border: '0.5px solid var(--border)', borderRadius: 10, padding: '1rem' }}>
                <div style={{ fontWeight: 500, marginBottom: 12 }}>Today's appointments</div>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                  <tbody>
                    {APPTS.map(([time, patient, doctor, status, kind]) => (
                      <tr key={time} style={{ borderTop: '0.5px solid var(--border)' }}>
                        <td style={{ padding: '8px 4px', color: 'var(--sub)' }}>{time}</td>
                        <td style={{ padding: '8px 4px' }}>{patient}</td>
                        <td style={{ padding: '8px 4px', color: 'var(--sub)' }}>{doctor}</td>
                        <td style={{ padding: '8px 4px', textAlign: 'right' }}>
                          <span style={{
                            background: `var(--${kind}-soft)`, color: `var(--${kind})`,
                            fontSize: 11, padding: '3px 8px', borderRadius: 6,
                          }}>{status}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div style={{ background: 'var(--surface)', border: '0.5px solid var(--border)', borderRadius: 10, padding: '1rem' }}>
                <div style={{ fontWeight: 500, marginBottom: 12 }}>Bed occupancy</div>
                {BEDS.map(b => (
                  <div key={b.ward} style={{ marginBottom: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                      <span style={{ color: 'var(--sub)' }}>{b.ward}</span>
                      <span style={{ fontWeight: 500 }}>{b.occ}%</span>
                    </div>
                    <div style={{ background: 'var(--border)', borderRadius: 4, height: 6, overflow: 'hidden' }}>
                      <div style={{ background: b.color, width: `${b.occ}%`, height: '100%' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  )
}
